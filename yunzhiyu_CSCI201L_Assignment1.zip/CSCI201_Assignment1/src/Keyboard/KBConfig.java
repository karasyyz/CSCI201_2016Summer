package Keyboard;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class KBConfig {
	private Map<Character,Keyword> keys;
	//Constructor
	{
	keys = new HashMap<Character,Keyword>();
	}
	
	public class Keyword{
		private char Key;
		private Keyword[] KeyNeighbor;
		Keyword(char Key){ this.Key = Key;}
	
		public char getKey(){return Key;}
		public Keyword[] getNeighbor(){return KeyNeighbor;}	
	}
	
	public KBConfig(File KB_config)throws IOException{
		Scanner scan = new Scanner(KB_config);
		
		scan.useDelimiter("[,\n]");
		
		while(scan.hasNextLine()){
			Keyword kw = null;
			char Key = scan.next().charAt(0);
			// check repetition
			if(!keys.containsKey(Key)){
				kw = new Keyword(Key);
				// store kw as an element of keys
				keys.put(Key, kw); 
			}
			kw = keys.get(Key); // still need to initialize kw
			
			char [] Neighbor = scan.next().trim().toCharArray();
			kw.KeyNeighbor = new Keyword[Neighbor.length];
			
			for(int i= 0; i < Neighbor.length;i ++){
				Keyword buff = null;
				if(!keys.containsKey(Neighbor[i])){ 	// is there is no such KeyNeighbor
					buff = new Keyword(Neighbor[i]); 	// add it 
					keys.put(Neighbor[i], buff);
				}
				 kw.KeyNeighbor[i]= keys.get(Neighbor[i]); // add Neighbor to kw
			}
		}
			scan.close();
	}
	
	public Keyword getKeybutton(char k){
		if (keys.containsKey(k)){
			return keys.get(k);
		}
		else return null;
	}
	
}
