package Keyboard;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class KBoard {
	private KBoard(){};
	// create a keyboard Map
	static final Map<String, KBConfig> keyboard;
	// static constructor
	static{
		keyboard = new HashMap<String, KBConfig>();
	}
//==================================================
//==================================================
	public static boolean addKB(String KB_name, String FilePath){
		if(keyboard.containsKey(KB_name)){
			System.out.println("Keyboard name already exists");
			return false;
		}	
		File keyboardconfig = new File(FilePath);
		if(!keyboardconfig.exists()){
			System.out.println("keyboard configuration already exists");
			return false;
		}	
		boolean loaded = false;
		try{
			KBConfig KB = new KBConfig(keyboardconfig);
			keyboard.put(KB_name, KB);
			System.out.println("keyboard loaded successfully");
			loaded = true;
		}catch(IOException e){
			System.out.println("Failure to load keyboard:" + KB_name);
		}
		return loaded;
	}
	public static KBConfig RetrieveKB(String KB_Name){
		return keyboard.get(KB_Name);
	}
}
