package Trie;
import Keyboard.KBConfig;
import Trie.trie.Node;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;
import java.util.Vector;
import java.util.Comparator;


public class WordChecker {
	
	public static String[] PossibleCorrections(String Mistyped, KBConfig kb, trie WL){		
		Vector<String> CorrectWords = new Vector<String>();
		//===================================================
		trie PC = new trie();// PC == Possible Correct words
		Vector<Node> n = new Vector<Node>();
		n.add(PC.getRoot());
		for(int i = 0; i < Mistyped.length();i ++){
			char c =  Mistyped.charAt(i);
			Vector<Node> container = new Vector<Node>();
			for(int j = 0; j < n.size(); j++){
				Node tn = n.get(j);
				KBConfig.Keyword keys = kb.getKeybutton(c);
				tn.add(keys.getKey());
				container.add(tn);
				for(KBConfig.Keyword buff: keys.getNeighbor()){
					tn.add(buff.getKey());
					container.add(tn);
				}
			}
			n = container;
		}
		for(int i = 0; i < n.size(); i ++){
			Node buff = n.get(i);
			buff.ConfirmWord();
		}
		//========================================================
		Node[] nodes = PC.RetrieveWord();
		for(int i = 0; i < nodes.length;i++){
			Node t = nodes[i];
			String word = t.getWord();
			if(WL.Check(word)){CorrectWords.add(word);}
		}
		String[] CW = new String[CorrectWords.size()];
		for(int i = 0; i <CorrectWords.size(); i ++ ){
			CW[i] = CorrectWords.get(i);
		}
		
		//====================================================
		return CW;
	}
	
	public static String[] Recommendation(String Mistyped, KBConfig kb, trie WL){
		Vector<String> RCMD = new Vector<String>();
//================================================================
		trie PC = new trie();// PC == Possible Correct words
		ArrayList<Node> n = new ArrayList<Node>();
		n.add(PC.getRoot());
		//ArrayList<Node> container = new ArrayList<Node>();
		//======================================================
		for(int i = 0; i < Mistyped.length();i ++){
			//store letter into c
			Character c =  Mistyped.charAt(i);
			ArrayList<Node> container = new ArrayList<Node>();
			
			for(int j = 0; j < n.size(); ++j){
				Node nn = n.get(j); // nothing here
				// fetch the key letter
				KBConfig.Keyword keys = kb.getKeybutton(c);
				Node buffer = nn.add(keys.getKey());
				container.add(buffer);
				for(KBConfig.Keyword buff: keys.getNeighbor()){
					buffer = nn.add(buff.getKey());
					container.add(buffer);
				}
			}
			n = container;
		}
		//=======================================================
		for(int a = 0; a < n.size(); a ++){
			Node buff = n.get(a); // I got nothing here
			buff.ConfirmWord();
		}
//================================================================
		Node[] nodes = PC.RetrieveWord();
		
		for(int i = 0; i < nodes.length; i++){
			// nothing here
			Node t = nodes[i];
			String prefix = t.getWord();
			//System.out.println(prefix);
			// check if it is a prefix
			if(WL.Check(prefix)){
				//String[] words = SamePrefixWords(word,WL);
//================================================================
				Node tt = WL.Search(prefix);
				if(tt == null){return null;}
				// SPW = Same Prefix Words
				Vector<String> SPW = new Vector<String>();
				Stack<Node> stack = new Stack<Node>();
				stack.add(tt);
				while(!stack.isEmpty()){
					tt = stack.pop();
					if(tt.ifWord()){
						//System.out.println(tt.getWord());
					}
					stack.addAll(tt.getAllKids());
				}
				//words store all the same prefix words
				String[] words = new String[SPW.size()];
				for(int k = 0; k < SPW.size();k++){
					String buff = SPW.get(k);
					words[k] = buff;
					//System.out.println(buff);
				}
//================================================================
				for(int j = 0; j < words.length; j++){
					RCMD.add(words[j]);
				}
			}
		}
		String[] results = RCMD.toArray(new String[RCMD.size()]);
		return results;
	}
	
//=================Helper function====================================
	
	static class DifferenceCalculator implements Comparator<String>{
		//difference by 1 length add 1 score
		//difference by 1 character add 1 score
		private String string;
		DifferenceCalculator(String string){this.string = string;}
		
		@Override
		public int compare(String str1, String str2){
			// in length, shorter or longer will both cause the
			// score goes higher
			int score = (str1.length()-str2.length());
			for(int i = 0; i < string.length();i ++){
				// if str1 is different from string, while str2 is the same
				//score +1
				if((str1.charAt(i)!=string.charAt(i))&& (str2.charAt(i)== string.charAt(i))){
					score++;
				}
				//if str2 is different from string,while str2 is the same
				//score -1
				else if((str1.charAt(i)==string.charAt(i))&& (str2.charAt(i)!= string.charAt(i))){
					score--;
				}
			}
			return score;
		}
	}
	public static void rank(String errorString, String[] Suggestions){
		DifferenceCalculator comparator = new DifferenceCalculator(errorString);
		Arrays.sort(Suggestions,comparator);
	}
	
	public static String[] TopTenList(String word, String[] CorrectWords){
		Vector<String> TopTen = new Vector<String>();
		int size = CorrectWords.length;
		DifferenceCalculator scorer = new DifferenceCalculator(word);
		int threshold =  scorer.compare(word, CorrectWords[9]);
		
		for(int i = 0; i < 10; i++){
			TopTen.add(CorrectWords[i]);
		}
		
		int extraIndex = 10;
		while(threshold == scorer.compare(word, CorrectWords[extraIndex])){
			String bonus = CorrectWords[extraIndex];
			TopTen.add(bonus);
			extraIndex++;
			if(extraIndex == size){break;}
		}
		String[] TTList = TopTen.toArray(new String[TopTen.size()]);
		return  TTList;
	}
}


