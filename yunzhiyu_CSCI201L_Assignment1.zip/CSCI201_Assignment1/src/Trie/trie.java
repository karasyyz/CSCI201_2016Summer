package Trie;


import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
public final class trie {
	//======Trie Private Member Data================================== 
	private final Map<String, Node> CompleteWord;
	private final Node TrieRoot;
	
	{
		TrieRoot = new Node('\0');
		CompleteWord = new HashMap<String, Node>();
	}
	
	public Node getRoot(){
		return TrieRoot;
	}
// first lets build Tree Node first===================================
	public class Node{
		// private data========================
		private char CH;
		private Node Parent;
		private String word;
		private Map<Character,Node> kids;
		private boolean isWord;
		
		//=====================================
		public boolean ifWord(){
			return isWord;
		}

		{ //instance constructor
			kids = new HashMap<Character,Node>();
			Parent = null;
			isWord = false;
		}
		//===========helper function===========
		public Node(char CH){
			this.CH = CH;
		}
		
		public String getWord(){
			return word;
		}
		public char getChar(){
			return CH;
		}
		
		public void setParent(Node P){
			this.Parent = P;
		}
		
		public Node getParent(){return Parent;}
		
		public Collection<Node> getAllKids(){return kids.values();}
		
		public Node add(char k){
			
			if(kids.containsKey(k)){
			 return kids.get(k); // new letter already existed
			}
			else{
				Node NewNode= new Node(k);
				NewNode.Parent = this;
				return NewNode;
			}
		}
		
		public void ConfirmWord(){  // check if from this node back to root 
			Node node = this;		// contains a whole word
			StringBuffer WordAdding = new StringBuffer();
			while(node.Parent!=null){
				WordAdding.insert(0, node.getChar());
				node = node.getParent();
			}
			if( !CompleteWord.containsKey(WordAdding.toString())){ 
				word = WordAdding.toString();
				CompleteWord.put(word, this);
				isWord = true;
			}
		}
		
		//=====================================
	}
//====================================================================
//====================Trie helper function============================
	
	public Node[] RetrieveWord(){
		Node [] allNodes = new Node[CompleteWord.size()];
		CompleteWord.values().toArray(allNodes);
		//String []words = new String[CompleteWord.size()];
		//CompleteWord.keySet().toArray(words);
		//for(int i = 0; i < allNodes.length; ++i){
		//System.out.println(words[i]);
		//}
		return allNodes;
	}
	public void addNode(String word){
		if(word == null || word.length() == 0) return;
		
		Node t = TrieRoot; // new Trie Node
		Map<Character,Node> kids = t.kids;
		
		int size = word.length();
		//complete new Node
		// complete its kids
		for(int i = 0; i < size; ++i){   
			char buff = word.charAt(i);
			if(!kids.containsKey(buff)){ 	// if current character is not
				Node child = new Node(buff);// in the Node's kids map
				child.setParent(t);
				kids.put(buff, child);		// add them into the map	
			}
			t = kids.get(buff); // fetch the child and go on
			kids = t.kids;
			if(i == word.length()-1){
			t.word = word;
			// if there is no such a complete word, add it into list
				if(!CompleteWord.containsKey(word)){
					CompleteWord.put(word, t);
					t.isWord = true;
				}
			}
		}
	}  
	public Node Search(String word){
		Map<Character, Node> m = TrieRoot.kids;
		Node n = null;
		int size = word.length();
		for(int i = 0; i < size; i++){
			// if there is corresponding letter, keep looking.
			char buff = word.charAt(i);
			if(m.containsKey(buff)){
				n= m.get(buff);
				m = n.kids;
			}
			else{return null;}
		}
		return n;
	}
	
	public boolean Check(String word){
		Node t = Search(word);
		return (t!=null && t.word!=null);
	}
	
}
