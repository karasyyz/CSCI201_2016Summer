package Trie;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import java.io.FileReader;


import Keyboard.KBConfig;
import Keyboard.KBoard;
import Trie.trie;

public class FileChecker {
	private static Scanner scan;
	
	static{
		scan = new Scanner(System.in);
	}
	private static trie WL;
	private static KBConfig kb;
	private static File txtFile = null;
	private static File wlFile = null;
	private static File kbFile = null;
	//===============Error Collection Class================
	public static class ErrorCollection{
		private String EWord;
		private String[] CorrectList;
		
		ErrorCollection(String ErrorWord,String[] CorrectList){
			this.EWord = ErrorWord;
			this.CorrectList = CorrectList;
		}
		
		public static void WriteFile(ErrorCollection[] collection, File filename){
			PrintWriter wrt = null;
			try{
				wrt = new PrintWriter(filename);
				for(int i = 0; i < collection.length;i++){
					ErrorCollection result = collection[i];
					wrt.write(result.EWord+" - ");
					for(int j = 0; j < result.CorrectList.length; j++){
						wrt.write(result.CorrectList[j]+" ");
					}
					wrt.write("\n");
				}
				wrt.flush();
			}catch(FileNotFoundException e){
				System.out.println("Cannot find the output file!");
			}finally{
				if(wrt!=null) wrt.close();
			}
		}
		//test
		public static void PrintOut(ErrorCollection[] collection){
			for(int i = 0; i < collection.length;i++){
				ErrorCollection result = collection[i];
				System.out.print(result.EWord+" - ");
				for(int j = 0; j < result.CorrectList.length; j++){
					System.out.print(result.CorrectList[j]+" ");
				}
			}
			System.out.print("\n");
		}
	}
	//==============================================
	
	public String[] findError(String Line){
		if(Line == null) return null;
		
		Vector<String> Errors = new Vector<String>();
			Line = Line.replaceAll("^A-Za-z","");
			Scanner scn = new Scanner(Line);
			scn.useDelimiter("([^A-Za-z])");
			while(scn.hasNext()){
				String string = scn.next();
				if(string == null|| string.length() ==0){
					continue;
				}
					string = string.toLowerCase();
				if(WL.Check(string) == false){
						Errors.add(string);
				}
		}
			scn.close();
			String[] errors = Errors.toArray(new String[Errors.size()]);
		return errors;
	}
	public String[] giveSuggestions(String errorWord){
		String[] Suggestions = WordChecker.Recommendation(errorWord, kb, WL);
		WordChecker.rank(errorWord, Suggestions);
		
		String[] TopTen;

		if(Suggestions.length < 10){
			TopTen = new String[Suggestions.length];
			for(int i = 0; i < Suggestions.length; i++){
				if(i<Suggestions.length){
					TopTen[i] = Suggestions[i];
				}
				else if(i>=Suggestions.length){
					break;
				}
			}
		}
		else{
			TopTen = WordChecker.TopTenList(errorWord, Suggestions);
		}
		return TopTen;
	}
	
	public void loadWordList(File wlFile){
		if(wlFile==null||!wlFile.exists()){
			System.out.println("Please enter the name of a valid .wl file.");
			String filename = scan.nextLine();
			while(!filename.endsWith(".wl.txt")){
				System.out.println("Please enter again");
				filename = scan.nextLine();
			}
			wlFile = new File(filename);
		}
		try{
			BufferedReader br = new BufferedReader(new FileReader(wlFile));
			String Line = null;
			WL = new trie();
			Line = br.readLine();
			while(Line!=null){
				WL.addNode(Line);
				Line = br.readLine();
			}
			br.close();
		}catch(IOException e){
			WL = null;
			System.out.println("Word list input failled ");
		}
	}
	
	public void loadKeyboard(File kbFile){
		String filename= null;
		if(kbFile==null||!kbFile.exists()){
			System.out.println("Please enter the name of a valid .kb file.");
			filename = scan.nextLine();
			while(!filename.endsWith(".kb.txt")){
				System.out.println("Please enter again");
				filename = scan.nextLine();
			}
			kbFile = new File(filename);
		}
		KBoard.addKB(filename, kbFile.getAbsolutePath());
		kb = KBoard.RetrieveKB(filename);
	}
	
	public ErrorCollection[] GetCollection(File txtFile){
		String filename = null;
		BufferedReader br = null;
		
		Vector<ErrorCollection> Errors = new Vector<ErrorCollection>();
		
		if(txtFile==null||!txtFile.exists()){
			System.out.println("Please enter the name of a valid .txt file.");
			filename = scan.nextLine();
			
			while(!filename.endsWith(".txt")){
				System.out.println("Please enter again");
				filename = scan.nextLine();
			}
			txtFile = new File(filename);
		}
		System.out.println("Start reading text.txt file");
		try{
			
			br = new BufferedReader(new FileReader(txtFile));
			String Line;
			Line = br.readLine();
			System.out.println("read line");
			while(Line != null){
				String[] EW = findError(Line);
				for(String buff:EW){
					Errors.add(new ErrorCollection(buff,giveSuggestions(buff)));
				}
				Line = br.readLine();
			}
			System.out.println("ErrorCollecting");
		}catch(IOException e){
			Errors = null;
			System.out.println("Cannot generate error file.");
		}
		ErrorCollection[] CompleteList = Errors.toArray(new ErrorCollection[Errors.size()]);
		return CompleteList;
	}
	
	public static void main(String []args){
		for(String fileName : args) {
			if(fileName.endsWith(".wl.txt")) {
				wlFile = new File(fileName);
			} else if(fileName.endsWith(".kb.txt")) {
				kbFile = new File(fileName);
			} else if(fileName.endsWith(".txt")) {
				txtFile = new File(fileName);
			}
		}
		FileChecker fc = new FileChecker();
		fc.loadWordList(wlFile);
		fc.loadKeyboard(kbFile);
		ErrorCollection[] FinalResult = fc.GetCollection(txtFile);
		System.out.println("all files ready");
		if(FinalResult != null){
			ErrorCollection.PrintOut(FinalResult);
			ErrorCollection.WriteFile(FinalResult, new File(new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date())+".txt"));
		}
		System.out.println("Program succeeds!!!");
	}
}

